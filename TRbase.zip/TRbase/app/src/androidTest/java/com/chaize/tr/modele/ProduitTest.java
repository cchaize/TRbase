package com.chaize.tr.modele;

import org.junit.Test;

import static org.junit.Assert.*;

public class ProduitTest {

    private Produit prd = new Produit("1234567890123", "Salade", 2);

    private Integer flg = 2;

    @Test
    public void getFlgTR() {
        assertEquals(flg, prd.getFlgTR());
    }
}