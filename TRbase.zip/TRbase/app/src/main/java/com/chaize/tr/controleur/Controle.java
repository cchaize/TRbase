package com.chaize.tr.controleur;

import android.content.Context;

import com.chaize.tr.modele.AccesDistant;
import com.chaize.tr.modele.Produit;
import com.chaize.tr.outils.Serializer;
import com.chaize.tr.vue.MajActivity;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public final class Controle {

    private static Controle instance = null;
    private static Produit produit;
    private static String nomfic = "saveProduct";
//    private static AccesLocal accesLocal;
    private static AccesDistant accesDistant;
    private static Context contexte;
    private static Integer magasin=0;
    private Controle(){
        super();
    }

    /**
     * Création de l'instance
     * @return  instance
     */
    public static final Controle getInstance(Context contexte) {
        if (contexte != null) {
            Controle.contexte = contexte;
        }
        if (Controle.instance==null) {
            Controle.instance = new Controle();
//            accesLocal = new AccesLocal(contexte);
            accesDistant = new AccesDistant();
        }
        return Controle.instance;
    }

    public void chercheProduit(String code, Context contexte) throws TRexception {
        //recupSerialize(contexte);
        //produit = accesLocal.recupProduit(code);
        produit = null;

        if (this.magasin==0)
            throw new TRexception(1, TRexception.getMessage(1));

        List param = new ArrayList();
        param.add(code);
        param.add(this.magasin);
        accesDistant.envoi("lecture", new JSONArray(param));
    }
    public void creerProduit(String code, String description, Context contexte){
            produit = new Produit(code, magasin, description);
            Serializer.serialize(nomfic, produit, contexte);
    }

    public void setProduit(Produit produit) {
        Controle.produit = produit;
        ((MajActivity) contexte).afficheProduit();
    }


    public void enregProduit(String code, String description, Integer flgTR, Context contexte){
        produit = new Produit(code, this.magasin, description, flgTR);
        //Serializer.serialize(nomfic, produit, contexte);
//        accesLocal.ajout(produit);
        accesDistant.envoi("enreg", produit.convert2JSONArray());
    }

    public Integer getFlgTR() {
        if (produit==null)
            return 0;
        return produit.getFlgTR();
    }

    /**
     * Récupération de l'objet sérialisé (Produit)
     * @param contexte
     */
    //private static void recupSerialize(Context contexte){
    public static void recupSerialize(Context contexte){
        produit = (Produit) Serializer.deserialize(nomfic, contexte);
    }

    public String getCode(){
        if (produit==null)
            return "**************";
        return produit.getCode();
    }

    public static Integer getMagasin() {
        return magasin;
    }

    public String getDescription(){
        if (produit==null)
            return "inconnu";
        return produit.getDescription();
    }
}
