package com.chaize.tr.vue;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v4.;

import com.chaize.tr.R;

public class ShopActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);

        init();
    }

    private void init(){
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new ListViewFragment(), "ListView");
        viewPager.setAdapter(adapter);

    }
}
