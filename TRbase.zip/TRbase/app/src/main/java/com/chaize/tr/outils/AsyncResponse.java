package com.chaize.tr.outils;

public interface AsyncResponse {
    void processFinish(String output);
}
