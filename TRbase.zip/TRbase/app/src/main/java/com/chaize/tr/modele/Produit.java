package com.chaize.tr.modele;

import org.json.JSONArray;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Produit implements Serializable {
    private String code;
    private Integer magasin;
    private String description;
    private Integer flgTR; // 0=inconnu 1=Non Eligible 2=Eligible TR

    public Produit(String code, Integer magasin, String description, Integer flgTR) {
        this.code = code;
        this.magasin = magasin;
        this.description = description;
        if (flgTR>=0 && flgTR<3)
            this.flgTR = flgTR;
        else
            this.flgTR = 0;
    }

    public Produit(String code, Integer magasin, String description) {
        this.code = code;
        this.magasin = magasin;
        this.description = description;
        this.flgTR = getFlgTRfromBase(this.code);
    }

    public String getCode() {
        return code;
    }

    public Integer getMagasin() {
        return magasin;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public Integer getFlgTR() {
        return Math.min(2,Math.max(0,flgTR));
    }

    public static Integer getFlgTRfromBase(String code) {
        return (int) (Math.random()*3);
    }

    /**
     * conversion du produit au format JSON
     * @return
     */
    public JSONArray convert2JSONArray() {
        List laListe = new ArrayList();
        laListe.add(code);
        laListe.add(magasin);
        laListe.add(description);
        laListe.add(flgTR);
        return new JSONArray(laListe);
    }
}
