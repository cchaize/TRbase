package com.chaize.tr.modele;

import android.util.Log;

import com.chaize.tr.controleur.Controle;
import com.chaize.tr.outils.AccesHTTP;
import com.chaize.tr.outils.AsyncResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AccesDistant implements AsyncResponse {

    // constante
    private static final String SERVERADDR = "http://cyril.chaize.free.fr/baseTR/serveurBaseTR.php";

    private Controle controle;

    public AccesDistant(){
        controle = Controle.getInstance(null);
    }

    /**
     * retour du serveur distant
     * @param output
     */
    @Override
    public void processFinish(String output) {
        Log.d("serveur", "******************* "+output);
        //découpage du message reçu avec %
        String[] message = output.split("%");
        // dans message[0] : "enreg", "lecture", "Erreur !"
        // dans message[1] : reste du message

        // s'il y a 2 cases
        if (message.length>1){
            if (message[0].equals("enreg")){
                Log.d("enreg", "******************* "+message[1]);
            } else {
                if (message[0].equals("lecture")){
                    Log.d("lecture", "******************* "+message[1]);
                    try {
                        Produit produit;
                        if (message[1].equals("notfound")) {
                            produit = new Produit(message[2], controle.getMagasin(), "inconnu", 0);
                        } else {
                            JSONObject info = new JSONObject(message[1]);
                            String code = info.getString("code");
                            String desc = info.getString("description");
                            Integer flgtr = info.getInt("flgTR");

                            produit = new Produit(code, controle.getMagasin(), desc, flgtr);
                        }
                        controle.setProduit(produit);

                    } catch (JSONException e) {
                        Log.d("Erreur", "conversion JSON impossible "+e.toString());
                    }
                } else {
                    if (message[0].equals("Erreur !")) {
                        Log.d("Erreur !", "******************* " + message[1]);
                    }
                }
            }
        }
    }

    public void envoi(String operation, JSONArray lesDonneesJSON) {
        AccesHTTP accesDonnees = new AccesHTTP();
        // lien de délégation
        accesDonnees.delegate = this;
        // ajout parametres
        accesDonnees.addParam("operation", operation);
        accesDonnees.addParam("lesdonnees", lesDonneesJSON.toString());
        // appel au serveur
        accesDonnees.execute(SERVERADDR);
    }

}
