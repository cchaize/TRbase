package com.chaize.tr.modele;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.chaize.tr.outils.MySQLiteOpenHelper;

public class AccesLocal {

    private String nomBase = "bddTR.sqlite";
    private Integer versionBase = 1;
    private MySQLiteOpenHelper accesBDD;
    private SQLiteDatabase bdd;

    public AccesLocal(Context contexte) {
        accesBDD = new MySQLiteOpenHelper(contexte,nomBase,null,versionBase);
    }

    /**
     * Ajout d'un produit dans la BDD
     * @param produit
     */
    public void ajout(Produit produit) {
        bdd = accesBDD.getWritableDatabase();
        String req = "insert into products (code, description, flgTR)"
                + " values ('"+produit.getCode()+"','"+produit.getDescription()+"',"+produit.getFlgTR()+")";
        bdd.execSQL(req);
    }
/*
    public Produit recupProduit(String code) {
        bdd = accesBDD.getWritableDatabase();
        bdd = accesBDD.getReadableDatabase();
        Produit produit = null;
        String req = "Select * from products Where code='"+code+"'";
        Cursor curseur = bdd.rawQuery(req, null);
        curseur.moveToFirst();
        if (!curseur.isBeforeFirst()) {
            String desc = curseur.getString(1);
            Integer flgTR = curseur.getInt(2);
            produit = new Produit(code, desc, flgTR);
        }
        return produit;
    }
*/
}
